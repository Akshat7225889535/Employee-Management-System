package com.thinking.machines.hr.pl.exceptions;
public class ModelException extends Exception
{
public ModelException(String message)
{
super(message);
}
}