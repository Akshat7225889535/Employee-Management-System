


package com.thinking.machines.hr.pl;
import  com.thinking.machines.hr.pl.ui.*;
public class Main
{
public static void main(String gg[])
{
DesignationUI designationUI=new DesignationUI();
designationUI.setVisible(true);
//SplachScreen splash = new SplashScreen();
designationUI.show(2000);
designationUI.hide();
}
}