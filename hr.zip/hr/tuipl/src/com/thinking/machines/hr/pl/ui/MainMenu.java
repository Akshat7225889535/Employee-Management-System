package com.thinking.machines.hr.pl.ui;
import com.thinking.machines.hr.dl.exceptions.*;
import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.hr.bl.exceptions.*;
import com.thinking.machines.hr.bl.interfaces.*;
import com.thinking.machines.hr.bl.managers.*;
import com.thinking.machines.hr.bl.pojo.*;
import com.thinking.machines.common.*;
import java.util.*;
public class MainMenu
{
public void show()
{
int ch;
while(true)
{
System.out.println("Menu");
System.out.println("1. Designation Master");
System.out.println("2. Employee Master");
System.out.println("3. Exit");
ch=Keyboard.getInt("Enter Your Choice(1-3):");
if(ch<1|| ch>3)
{
System.out.println("Invalid choice ");
return;
}
if(ch==1)
{
while(true)
{
System.out.println("-----------------------------");
System.out.println("     DESIGNATION MASTER     ");
System.out.println("1.  Add");
System.out.println("2.  Edit");
System.out.println("3.  Delete");
System.out.println("4.  Count");
System.out.println("5.  Display");
System.out.println("6.  Search");
System.out.println("7.  Validation");
System.out.println("8.  Other");
System.out.println("9.  Exit");
int d=Keyboard.getInt("Enter your Choice (1-8):");
System.out.println("-----------------------------");
if(d<1||d>8)
{
System.out.println("Invalid Choice ");
return;
}
if(d==1)
{
DesignationUI dui1=new DesignationUI();
dui1.add();
}
if(d==2)
{
DesignationUI dui2=new DesignationUI();
dui2.update();
}
if(d==3)
{
DesignationUI dui3=new DesignationUI();
dui3.delete();
}
if(d==4)
{
DesignationUI dui4=new DesignationUI();
dui4.getCount();
}
if(d==5)
{
DesignationUI dui5=new DesignationUI();
dui5.getDesignations();
}
if(d==6)
{
while(true)
{
System.out.println("               SEARCH   ");
System.out.println("1. Search By Designation Code");
System.out.println("2. Search By Designation Title");
System.out.println("3. Exit");
int d1=Keyboard.getInt("Enter Your Choice(1-3)");
if(d1<1||d1>3)
{
System.out.println("Invalid Choice...!");
return;
}
if(d1==1)
{
DesignationUI de1=new DesignationUI();
de1.getByCode();
} 
if(d1==2)
{
DesignationUI d2=new DesignationUI();
d2.getByTitle();
}
if(d1==3)
{
break;
}
}
}
if(d==7)
{
while(true)
{
System.out.println("       VALIDATION    ");
System.out.println("1. Validate By Code");
System.out.println("2. Validate By Title");
System.out.println("3. Exit");
int v=Keyboard.getInt("Enter Your Choice(1-3)");
if(v<1||v>3)
{
System.out.println("Invalid Choice....");
return;
}
if(v==1)
{
DesignationUI v1=new DesignationUI();
v1.codeExists();
}
if(v==2)
{
DesignationUI v2=new DesignationUI();
v2.titleExists();
}
if(v==3)
{
break;
}
}
}
if(d==8)
{
while(true)
{
System.out.println("       Others    ");
System.out.println("1.  Count Employee With Designation");
System.out.println("2.  Validate the Attatchment of Employee With Designation ");
System.out.println("3.  Exit");
int c=Keyboard.getInt("Enter Your Choice(1-3) :");
if(c<1||c>3)
{
System.out.println("Invalid Choice ");
return;
}
if(c==1)
{
DesignationUI c1=new DesignationUI();
c1.getEmployeeCountWithDesignation();
}
if(c==2)
{
DesignationUI c2=new DesignationUI();
c2.isAttachedToAnEmployee();
}
if(c==3)
{
break;
}
}
}
if(d==9)
{
break;
}
}//if(ch==1) loop ends
}//while(true) loop ends
if(ch==2)
{
while(true)
{
System.out.println("-----------------------------");
System.out.println("     EMPLOYEE  MASTER     ");
System.out.println("1. Add  ");
System.out.println("2. Edit");
System.out.println("3. Delete");
System.out.println("4. Count ");
System.out.println("5. Display");
System.out.println("6. Search");
System.out.println("7. Validation");
System.out.println("8. Exit");
int e=Keyboard.getInt("Enter Your Choice(1-8): ");
System.out.println("-----------------------------");
if(e<1 || e>8)
{
System.out.println("Invalid Choice");
return;
}
if(e==1)
{
EmployeeUI eui1=new EmployeeUI();
eui1.add();
}
if(e==2)
{
EmployeeUI eui2=new EmployeeUI();
eui2.update();
}
if(e==3)
{
EmployeeUI eui3=new EmployeeUI();
eui3.delete();
}
if(e==4)
{
EmployeeUI eui4=new EmployeeUI();
eui4.getCount();
}
if(e==5)
{
EmployeeUI eui5=new EmployeeUI();
eui5.getAll();
}
if(e==6)
{
while(true)
{
System.out.println("         Search    ");
System.out.println("1. Search By Employee ID");
System.out.println("2. Search By Aadhar Card Number");
System.out.println("3. Search By PAN Number");
System.out.println("4. Exit");
int y=Keyboard.getInt("Enter Your Choice(1-4)");
if(y<1||y>4)
{
System.out.println("Invalid Choice....");
return;
}
if(y==1)
{
EmployeeUI e1=new EmployeeUI();
e1.getByEmployeeId();
}
if(y==2)
{
EmployeeUI e2=new EmployeeUI();
e2.getByAadharCardNumber();
}
if(y==3)
{
EmployeeUI e3=new EmployeeUI();
e3.getByPanNumber();
}
if(y==4)
{
break;
}
}
}
if(e==7)
{
while(true)
{
System.out.println("   VALIDATION     ");
System.out.println("1. Validate by Employee ID");
System.out.println("2. Validate by Aadhar Card Number");
System.out.println("3. Validate by PAN Number");
System.out.println("4. Exit");
int a=Keyboard.getInt("Enter Your Choice(1-4)");
if(a<1||a>4)
{
System.out.println("Invalid Choice....");
return;
}
if(a==1)
{
EmployeeUI a1=new EmployeeUI();
a1.employeeIdExists();
}
if(a==2)
{
EmployeeUI a2=new EmployeeUI();
a2.aadharCardNumberExists();
}
if(a==3)
{
EmployeeUI a3=new EmployeeUI();
a3.panNumberExists();
}
if(a==4)
{
break;
}
}
}
if(e==8)
{
break;
}
}
}
if(ch==3)
{
break;
}
}//full while loop
}//show
}//main menu
