package com.thinking.machines.hr.pl;
import com.thinking.machines.hr.dl.exceptions.*;
import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.hr.bl.exceptions.*;
import com.thinking.machines.hr.bl.interfaces.*;
import com.thinking.machines.hr.bl.managers.*;
import com.thinking.machines.hr.bl.pojo.*;
import com.thinking.machines.common.*;
import com.thinking.machines.hr.pl.ui.*;
import java.util.*;
public class main
{
public static void main(String gg[])
{
MainMenu mm=new MainMenu();
mm.show();
}
}