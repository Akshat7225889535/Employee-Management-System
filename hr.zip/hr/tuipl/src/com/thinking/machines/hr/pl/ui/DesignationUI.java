

package com.thinking.machines.hr.pl.ui;
import com.thinking.machines.hr.dl.exceptions.*;
import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.hr.bl.exceptions.*;
import com.thinking.machines.hr.bl.interfaces.*;
import com.thinking.machines.hr.bl.managers.*;
import com.thinking.machines.hr.bl.pojo.*;
import com.thinking.machines.common.*;
import java.util.*;
public class DesignationUI
{
public void add()
{
while(true)
{
String vTitle=Keyboard.getString("Enter a Designation Title:");
try
{
DesignationInterface designation;
designation=new Designation();
designation.setTitle(vTitle);
DesignationManager d=DesignationManager.getDesignationManager();
d.add(designation);
System.out.println(vTitle+" added with code as : "+designation.getCode());
break;
}catch(BLException b)
{
List<String> list=b.getExceptions();
for(int i=0;i<list.size();i++)
{
String g=list.get(i);
System.out.println(g);
}
String k=Keyboard.getString("Do you want to Add records again(Y/N) :  : ");
if(k.equals("Y")==false &&k.equals("y")==false &&k.equals("N")==false &&k.equals("n")==false )
{
System.out.println("Invalid input..");
return;
}
if(k.equals("y") ||k.equals("Y"))
{
continue;
}
else
{
break;
}
}
}
}
public void update()
{
while(true)
{
int code=Keyboard.getInt("Enter a designation code to update :");
String title=Keyboard.getString("Enter a designation title to update :");
try
{
DesignationManagerInterface designationManager;
designationManager=DesignationManager.getDesignationManager();
DesignationInterface designation;
designation=new Designation();
designation.setCode(code);
designation.setTitle(title);
designationManager.update(designation);
System.out.println("Designation Updated....");
break;
}catch(BLException b)
{
List<String> list=b.getExceptions();
for(int i=0;i<list.size();i++)
{
String g=list.get(i);
System.out.println(g);
}
String k=Keyboard.getString("Do you want to update records again(Y/N) :  : ");
if(k.equals("Y")==false &&k.equals("y")==false &&k.equals("N")==false &&k.equals("n")==false )
{
System.out.println("Invalid input..");
return;
}
if(k.equals("y") ||k.equals("Y"))
{
continue;
}
else
{
break;
}
}
}
}
public void delete()
{
while(true)
{
int vCode=Keyboard.getInt("Enter a code to delete : ");
try
{
DesignationManagerInterface designationManager;
designationManager=DesignationManager.getDesignationManager(); 
designationManager.delete(vCode);
System.out.printf("designation deleted with code as %d\n",vCode);
break;
} catch(BLException b)
{
List<String> list=b.getExceptions();
for(int i=0;i<list.size();i++)
{
String g=list.get(i);
System.out.println(g);
}
String k=Keyboard.getString("Do you want to delete record again(Y/N) :  : ");
if(k.equals("Y")==false &&k.equals("y")==false &&k.equals("N")==false &&k.equals("n")==false )
{
System.out.println("Invalid input..");
return;
}
if(k.equals("y") ||k.equals("Y"))
{
continue;
}
else
{
break;
}
}
}
}
public void getByCode()
{
while(true)
{
int vCode=Keyboard.getInt("Enter a code to get  title:");
try
{
DesignationManagerInterface designationManager;
designationManager=DesignationManager.getDesignationManager();
DesignationInterface designation;
designation=new Designation();
designation=designationManager.getByCode(vCode);
String title=designation.getTitle();
System.out.println("Designation code : "+vCode+" is with title as : "+title);
break;
}catch(BLException b)
{
List<String> list=b.getExceptions();
for(int i=0;i<list.size();i++)
{
String g=list.get(i);
System.out.println(g);
}
String k=Keyboard.getString("Do you want to continue this operation again(Y/N) :  : ");
if(k.equals("Y")==false &&k.equals("y")==false &&k.equals("N")==false &&k.equals("n")==false )
{
System.out.println("Invalid input..");
return;
}
if(k.equals("y") ||k.equals("Y"))
{
continue;
}
else
{
break;
}
}
}
}
public void getByTitle()
{
while(true)
{
String vTitle=Keyboard.getString("Enter a title to get code :");
try
{
DesignationManagerInterface designationManager;
designationManager=DesignationManager.getDesignationManager();
DesignationInterface designation;
designation=new Designation();
designation=designationManager.getByTitle(vTitle);
int code=designation.getCode();
System.out.println("Designation title : "+vTitle+" is with code as : "+code);
break;
}catch(BLException b)
{
List<String> list=b.getExceptions();
for(int i=0;i<list.size();i++)
{
String g=list.get(i);
System.out.println(g);
}
String k=Keyboard.getString("Do you want to continue this operation again(Y/N) :  : ");
if(k.equals("Y")==false &&k.equals("y")==false &&k.equals("N")==false &&k.equals("n")==false )
{
System.out.println("Invalid input..");
return;
}
if(k.equals("y") ||k.equals("Y"))
{
continue;
}
else
{
break;
}
}
}
}
public static void getDesignations()
{
try
{
DesignationManager dm=DesignationManager.getDesignationManager();
List<DesignationInterface> designations=dm.getDesignations();
for(DesignationInterface designation:designations)
{
System.out.printf("Code %d ,Title %s \n",designation.getCode(),designation.getTitle());
}
}catch(BLException b)
{
List<String> list=b.getExceptions();
for(int i=0;i<list.size();i++)
{
String g=list.get(i);
System.out.println(g);
}
}
}
public void titleExists()
{
while(true)
{
String vTitle=Keyboard.getString("Enter designation title:");
try
{
DesignationManagerInterface designationManager;
designationManager=DesignationManager.getDesignationManager();
boolean fTitle=designationManager.titleExists(vTitle);
System.out.println("Is Designation code exists :" +fTitle);
break;
}catch(BLException b)
{
List<String> list=b.getExceptions();
for(int i=0;i<list.size();i++)
{
String g=list.get(i);
System.out.println(g);
}
String k=Keyboard.getString("Do you want to continue this operation again(Y/N) :  : ");
if(k.equals("Y")==false &&k.equals("y")==false &&k.equals("N")==false &&k.equals("n")==false )
{
System.out.println("Invalid input..");
return;
}
if(k.equals("y") ||k.equals("Y"))
{
continue;
}
else
{
break;
}
}
}
}
public void codeExists()
{
while(true)
{
int vCode=Keyboard.getInt("Enter designation code:");
try
{
DesignationManagerInterface designationManager;
designationManager=DesignationManager.getDesignationManager();
boolean fCode=designationManager.codeExists(vCode);
System.out.println("Is Designation code exists :" +fCode);
break;
}catch(BLException b)
{
List<String> list=b.getExceptions();
for(int i=0;i<list.size();i++)
{
String g=list.get(i);
System.out.println(g);
}
String k=Keyboard.getString("Do you want to continue this operation again(Y/N) :  : ");
if(k.equals("Y")==false &&k.equals("y")==false &&k.equals("N")==false &&k.equals("n")==false )
{
System.out.println("Invalid input..");
return;
}
if(k.equals("y") ||k.equals("Y"))
{
continue;
}
else
{
break;
}
}
}
}
public void getCount()
{
try
{
DesignationManagerInterface designationManager;
designationManager=DesignationManager.getDesignationManager();
int count;
count=designationManager.getCount();
System.out.println("Number of Designation added is :"+count);
}catch(BLException b)
{
List<String> list=b.getExceptions();
for(int i=0;i<list.size();i++)
{
String g=list.get(i);
System.out.println(g);
}
}
}
public void isAttachedToAnEmployee()
{
while(true)
{
int code=Keyboard.getInt("Enter a code :");
try
{
DesignationManagerInterface designationManager;
designationManager=DesignationManager.getDesignationManager();
boolean vCode=designationManager.isAttachedToAnEmployee(code);
System.out.println("Attached to an Employee :"+vCode);
break;
}catch(BLException b)
{
List<String> list=b.getExceptions();
for(int i=0;i<list.size();i++)
{
String g=list.get(i);
System.out.println(g);
}
String k=Keyboard.getString("Do you want to continue this operation again(Y/N) :  : ");
if(k.equals("Y")==false &&k.equals("y")==false &&k.equals("N")==false &&k.equals("n")==false )
{
System.out.println("Invalid input..");
return;
}
if(k.equals("y") ||k.equals("Y"))
{
continue;
}
else
{
break;
}
} 
}
}
public void getEmployeeCountWithDesignation()
{
while(true)
{
int code=Keyboard.getInt("Enter a code :");
try
{
DesignationManagerInterface designationManager;
designationManager=DesignationManager.getDesignationManager();
int count;
count=designationManager.getEmployeesCountWithDesignation(code);
System.out.println("Employees with designation code "+ code +" is "+count);
break;
}catch(BLException b)
{
List<String> list=b.getExceptions();
for(int i=0;i<list.size();i++)
{
String g=list.get(i);
System.out.println(g);
}
String k=Keyboard.getString("Do you want to continue this operation again(Y/N) :  : ");
if(k.equals("Y")==false &&k.equals("y")==false &&k.equals("N")==false &&k.equals("n")==false )
{
System.out.println("Invalid input..");
return;
}
if(k.equals("y") ||k.equals("Y"))
{
continue;
}
else
{
break;
}
}
}
}
}