



class Employee
{
private int rollNumber;
private String firstName;
private String lastName;
private int age;
private String fathersName;
publicEmployee()
{
this.rollNumber=0;
this.firstName="";
this.lastName="";
this.age=0;
this.fathersName="";
}
public void setRollNumber(int rollNumber)
{
this.rollNumber=rollNumber;
}
public int getRollNumber()
{
return this.rollNumber;
}
public void setFirstName(java.lang.String firstName)
{
this.firstName=firstName;
}
public java.lang.String getFirstName()
{
return this.firstName;
}
public void setLastName(java.lang.String lastName)
{
this.lastName=lastName;
}
public java.lang.String getLastName()
{
return this.lastName;
}
public void setAge(int age)
{
this.age=age;
}
public int getAge()
{
return this.age;
}
public void setFathersName(java.lang.String fathersName)
{
this.fathersName=fathersName;
}
public java.lang.String getFathersName()
{
return this.fathersName;
}



}