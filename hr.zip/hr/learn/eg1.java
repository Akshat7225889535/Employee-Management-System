


import java.lang.reflect.*;
class eg1psp
{
public static void main(String gg[])
{
try
{
Class c;
c=Class.forName("com.thinking.machines.hr.dl.dto.EmployeeDTO");
Field f[]=c.getDeclaredFields();
String fieldName;
Class fieldType;
for(int i=0;i<f.length;i++)
{
fieldName=f[i].getName();
fieldType=f[i].getType();
System.out.println("Field :"+fieldName);
System.out.println("Data type :"+fieldType);
}
String methodName;
Class ReturnType;
Class parameterTypes[];
Method methods[]=c.getMethods();
for(int e=0;e<methods.length;e++)
{
methodName=methods[e].getName();
ReturnType=methods[e].getReturnType();
parameterTypes=methods[e].getParameterTypes();
System.out.println("Name :"+methodName);
System.out.println("Return Type :"+ReturnType.getName());
for(int k=0;k<parameterTypes.length;k++)
{
//try getSimpleName() n place of getName()
System.out.println("parameter types :"+parameterTypes[k].getName());
System.out.println("parameter types as get simple :"+parameterTypes[k].getSimpleName());
}
}
}catch(ClassNotFoundException cnfe)
{
System.out.println(cnfe);
}
}
}