



 import java.util.*;
class eg4psp
{
public static void main(String gg[])
{
List<String> list=new ArrayList<String>();
int f=0;
int l=0;
int m=0;
int compare=0;
long starTime=System.nanoTime();
System.out.println(starTime);
for(int i=0;i<18000;i++)
{
String g=UUID.randomUUID().toString();
 if(list.size()==0)
{
list.add(g);
continue;
}
l=0;
f=list.size()-1;
while(true)
{
m=(l+f)/2;
compare=g.compareTo(list.get(m));
if(compare>0)
{
if(m==f)
{
list.add(f+1,g);
break;
}
compare=g.compareTo(list.get(m+1));
if(compare>0)
{
l=m+1;
}
else
{
list.add(m+1,g);
break;
}
}
else
{
if(m==f)
{
list.add(f,g);
break;
}
f=m;
}
}
}
System.out.println("....................");
for(int j=0;j<list.size();j++)
System.out.println(list.get(j)); 
long currentTime=System.nanoTime()-starTime;
System.out.println(currentTime);
}
}
 