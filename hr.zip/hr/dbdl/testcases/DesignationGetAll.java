import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.exceptions.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;
import java.sql.*;
import java.util.*;
import java.text.*;
public class DesignationGetAll
{
public static void main(String gg[])
{
try
{
DesignationDAOInterface designationDAO;
designationDAO=new DesignationDAO();
List<DesignationDTOInterface> designations;
designations=designationDAO.getAll();
for(DesignationDTOInterface designation:designations)
{
System.out.printf("Code :%d , Title : %s \n",designation.getCode(),designation.getTitle());
System.out.println("--------------------------------------------------------");
}
}catch(DAOException daoException)
{
System.out.println(daoException.getMessage());
}
}
}