


import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.exceptions.*;
import java.sql.*;
class ConnectionTestCase
{
public static void main(String gg[])
{
try
{
Connection c=DAOConnection.getConnection();
System.out.println("Connection Established");
c.close();
System.out.println("Connection closed");
}catch(DAOException d)
{
System.out.println(d.getMessage());
}

catch(Exception e)
{
System.out.println(e);
}
}
}