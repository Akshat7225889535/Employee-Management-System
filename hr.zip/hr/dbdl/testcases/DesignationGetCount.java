


import com.thinking.machines.hr.dl.exceptions.*;
import com.thinking.machines.hr.dl.dao.*;
public class DesignationGetCount
{
public static void main(String gg[])
{
try
{
System.out.println("Number of Designations :"+new DesignationDAO().getCount());
}catch(DAOException daoException)
{
System.out.println(daoException);
}
}
}