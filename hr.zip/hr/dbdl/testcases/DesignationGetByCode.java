import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.exceptions.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.common.*;
import java.math.*;
import java.text.*;
import java.util.*;
import java.io.*;
class DesignationGetByCode
{
public static void main(String gg[])
{
try
{
int code=Keyboard.getInt("Enter Designation Code : ");
DesignationDTOInterface designationDTO;
designationDTO=new DesignationDAO().getByCode(code);
System.out.println("Title : "+designationDTO.getTitle());
}catch(DAOException daoException)
{
System.out.println(daoException.getMessage());
}
}
}