package com.thinking.machines.hr.dl.dao;
import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.exceptions.*;
import com.thinking.machines.hr.dl.dto.*;
import java.math.*;
import java.io.*;
import java.text.*;
import java.sql.*;
import java.util.*;
public class EmployeeDAO implements EmployeeDAOInterface
{
public void add(EmployeeDTOInterface employeeDTO) throws DAOException
{
try
{
String vEmployeeId=null;
String vName=employeeDTO.getName().trim();
if(vName==null) throw new DAOException("Name Required");
if(vName.length()>35) throw new DAOException("Name should not be greater than 35 characters...!");
int vDesignationCode=employeeDTO.getDesignationCode();
java.util.Date vDateOfBirth=employeeDTO.getDateOfBirth();
java.sql.Date dob=new java.sql.Date(vDateOfBirth.getYear(),vDateOfBirth.getMonth(),vDateOfBirth.getDate());
BigDecimal vBasicSalary=employeeDTO.getBasicSalary();
boolean vIsIndian=employeeDTO.isIndian();
String vGender=employeeDTO.getGender();
String vPanNumber=employeeDTO.getPANNumber().trim();
String vAadharCardNumber=employeeDTO.getAadharCardNumber().trim();
boolean designationCodeExists=new DesignationDAO().codeExists(vDesignationCode);
if(designationCodeExists==false) throw new DAOException("Invalid Designation Code : "+vDesignationCode);
Connection connection=DAOConnection.getConnection();
int lastGeneratedCode=100000;
PreparedStatement preparedStatement;
preparedStatement=connection.prepareStatement("select * from employee where pan_number=?");
preparedStatement.setString(1,vPanNumber);
ResultSet resultSet;
resultSet=preparedStatement.executeQuery();
if(resultSet.next()==true)
{
resultSet.close();
preparedStatement.close();
connection.close();
throw new DAOException("Pan Number "+vPanNumber+" already Exists");
}
resultSet.close();
preparedStatement.close();
preparedStatement=connection.prepareStatement("select * from employee where aadhar_card_number=?");
preparedStatement.setString(1,vAadharCardNumber);
resultSet=preparedStatement.executeQuery();
if(resultSet.next()==true)
{
resultSet.close();
preparedStatement.close();
connection.close();
throw new DAOException("Aadhar Card Number "+vAadharCardNumber+" already Exists");
}
resultSet.close();
preparedStatement.close();
preparedStatement=connection.prepareStatement("insert into employee (name,designation_code,date_of_birth,basic_salary,gender,is_indian,pan_number,aadhar_card_number) values (?,?,?,?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS);
preparedStatement.setString(1,vName);
preparedStatement.setInt(2,vDesignationCode);
preparedStatement.setDate(3,dob);
preparedStatement.setBigDecimal(4,vBasicSalary);
preparedStatement.setString(5,vGender);
preparedStatement.setBoolean(6,vIsIndian);
preparedStatement.setString(7,vPanNumber);
preparedStatement.setString(8,vAadharCardNumber);
preparedStatement.executeUpdate();
resultSet=preparedStatement.getGeneratedKeys();
resultSet.next();
int employeeId=resultSet.getInt(1)+100000;
resultSet.close();
preparedStatement.close();
connection.close();
String newEmployeeId="EMP"+String.valueOf(employeeId);
employeeDTO.setEmployeeId(newEmployeeId);
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
}
public void update(EmployeeDTOInterface employeeDTO) throws DAOException
{
try
{
String vEmployeeId=employeeDTO.getEmployeeId();

if(vEmployeeId.length()<=3)throw new DAOException("Invalid Employee Id :"+vEmployeeId);

int employeeIdNumericPart=Integer.parseInt(vEmployeeId.substring(3));

if(employeeIdNumericPart<=100000)throw new DAOException("Invalid Employee Id :"+vEmployeeId);

employeeIdNumericPart=employeeIdNumericPart-100000;
String vName=employeeDTO.getName().trim();
if(vName==null) throw new DAOException("Name Required");
if(vName.length()>35) throw new DAOException("Name should not be greater than 35 characters...!");
int vDesignationCode=employeeDTO.getDesignationCode();
java.util.Date vDateOfBirth=employeeDTO.getDateOfBirth();
java.sql.Date dob=new java.sql.Date(vDateOfBirth.getYear(),vDateOfBirth.getMonth(),vDateOfBirth.getDate());
BigDecimal vBasicSalary=employeeDTO.getBasicSalary();
boolean vIsIndian=employeeDTO.isIndian();
String vGender=employeeDTO.getGender();
String vPanNumber=employeeDTO.getPANNumber().trim();
String vAadharCardNumber=employeeDTO.getAadharCardNumber().trim();
boolean designationCodeExists=new DesignationDAO().codeExists(vDesignationCode);
if(designationCodeExists==false) throw new DAOException("Invalid Designation Code : "+vDesignationCode);
Connection connection=DAOConnection.getConnection();
PreparedStatement preparedStatement;
preparedStatement=connection.prepareStatement("select * from employee where employee_id=?");
preparedStatement.setInt(1,employeeIdNumericPart);
ResultSet resultSet;
resultSet=preparedStatement.executeQuery();
if(resultSet.next()==false)
{
resultSet.close();
preparedStatement.close();
connection.close();
throw new DAOException("Invalid Employee ID ");
}
resultSet.close();
preparedStatement.close();
preparedStatement=connection.prepareStatement("select * from employee where pan_number=?");
preparedStatement.setString(1,vPanNumber);
resultSet=preparedStatement.executeQuery();
if(resultSet.next()==true)
{
resultSet.close();
preparedStatement.close();
connection.close();
throw new DAOException("Pan Number "+vPanNumber+" already Exists");
}
resultSet.close();
preparedStatement.close();
preparedStatement=connection.prepareStatement("select * from employee where aadhar_card_number=?");
preparedStatement.setString(1,vAadharCardNumber);
resultSet=preparedStatement.executeQuery();
if(resultSet.next()==true)
{
resultSet.close();
preparedStatement.close();
connection.close();
throw new DAOException("Aadhar Card Number "+vAadharCardNumber+" already Exists");
}
resultSet.close();
preparedStatement.close();
preparedStatement=connection.prepareStatement("update employee set name=?,designation_code=?,date_of_birth=?,basic_salary=?,gender=?,is_indian=?,pan_number=?,aadhar_card_number=? where employee_id=?");
preparedStatement.setString(1,vName);
preparedStatement.setInt(2,vDesignationCode);
preparedStatement.setDate(3,dob);
preparedStatement.setBigDecimal(4,vBasicSalary);
preparedStatement.setString(5,vGender);
preparedStatement.setBoolean(6,vIsIndian);
preparedStatement.setString(7,vPanNumber);
preparedStatement.setString(8,vAadharCardNumber);
preparedStatement.setInt(9,employeeIdNumericPart);
preparedStatement.executeUpdate();
preparedStatement.close();
connection.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
}
public void delete(String employeeId) throws DAOException
{
try
{
String vEmployeeId=employeeId;
if(vEmployeeId.length()<=3)throw new DAOException("Invalid Employee Id :"+vEmployeeId);

int employeeIdNumericPart=Integer.parseInt(vEmployeeId.substring(3));

if(employeeIdNumericPart<=100000)throw new DAOException("Invalid Employee Id :"+vEmployeeId);

employeeIdNumericPart=employeeIdNumericPart-100000;
Connection connection=DAOConnection.getConnection();
PreparedStatement preparedStatement;
preparedStatement=connection.prepareStatement("select * from employee where employee_id=?");
preparedStatement.setInt(1,employeeIdNumericPart);
ResultSet resultSet;
resultSet=preparedStatement.executeQuery();
if(resultSet.next()==false)
{
resultSet.close();
preparedStatement.close();
connection.close();
throw new DAOException("Invalid Employee ID ");
}
resultSet.close();
preparedStatement.close();
preparedStatement=connection.prepareStatement("delete from employee where employee_id=?");
preparedStatement.setInt(1,employeeIdNumericPart);
preparedStatement.executeUpdate();
preparedStatement.close();
connection.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
}
public int getCount() throws DAOException
{
int count=0;
try
{
Connection connection=DAOConnection.getConnection();
Statement statement=connection.createStatement();
ResultSet resultSet;
resultSet=statement.executeQuery("Select * from employee");
while(resultSet.next())
{
count++;
}
resultSet.close();
statement.close();
connection.close();
}catch(Exception e)
{
System.out.println(e);
}
return count;
}
public java.util.List<EmployeeDTOInterface> getAll() throws DAOException
{
try
{
java.util.List<EmployeeDTOInterface> list;
list=new LinkedList<>();
EmployeeDTOInterface employeeDTO;
Connection connection=DAOConnection.getConnection();
Statement statement=connection.createStatement();
ResultSet resultSet;
String vName;
String vEmployeeId;
int vDesignationCode;
java.util.Date vDateOfBirth;
BigDecimal vBasicSalary;
boolean vIsIndian;
String vGender;
String vPanNumber;
String vAadharCardNumber;
resultSet=statement.executeQuery("select * from employee");
while(resultSet.next())
{
vEmployeeId=resultSet.getString("employee_id");
vName=resultSet.getString("name");
vDesignationCode=resultSet.getInt("designation_code");
vDateOfBirth=resultSet.getDate("date_of_birth");
vBasicSalary=resultSet.getBigDecimal("basic_salary"); 
vIsIndian=resultSet.getBoolean("is_indian");
vGender=resultSet.getString("gender");
vPanNumber=resultSet.getString("pan_number");
vAadharCardNumber=resultSet.getString("aadhar_card_number");
employeeDTO=new EmployeeDTO();
String newEmployeeId="EMP"+String.valueOf(100000+resultSet.getInt(1));
employeeDTO.setEmployeeId(newEmployeeId);
employeeDTO.setName(vName);
employeeDTO.setDesignationCode(vDesignationCode);
employeeDTO.setDateOfBirth(vDateOfBirth);
employeeDTO.setBasicSalary(vBasicSalary);
employeeDTO.isIndian(vIsIndian);
if(vGender.equals("Male"))
{
employeeDTO.setGender(EmployeeDTOInterface.MALE);
}
else
{
employeeDTO.setGender(EmployeeDTOInterface.FEMALE);
}
employeeDTO.setPANNumber(vPanNumber);
employeeDTO.setAadharCardNumber(vAadharCardNumber);
list.add(employeeDTO);
}
resultSet.close();
statement.close();
connection.close();
return list;
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
}
public EmployeeDTOInterface getByEmployeeId(String employeeId) throws DAOException
{
try
{
EmployeeDTOInterface employeeDTO;
employeeDTO=new EmployeeDTO();
String vEmployeeId=employeeId;
if(vEmployeeId.length()<=3)throw new DAOException("Invalid Employee Id :"+vEmployeeId);

int employeeIdNumericPart=Integer.parseInt(vEmployeeId.substring(3));

if(employeeIdNumericPart<=100000)throw new DAOException("Invalid Employee Id :"+vEmployeeId);

employeeIdNumericPart=employeeIdNumericPart-100000;
Connection connection=DAOConnection.getConnection();
PreparedStatement preparedStatement;
preparedStatement=connection.prepareStatement("select * from employee where employee_Id=?");
preparedStatement.setInt(1,employeeIdNumericPart);
ResultSet resultSet;
resultSet=preparedStatement.executeQuery();
if(resultSet.next()==false)
{
resultSet.close();
preparedStatement.close();
connection.close();
throw new DAOException("Invalid Employeee ID : "+employeeId);
}
resultSet.close();
preparedStatement.close();
preparedStatement=connection.prepareStatement("select * from employee where employee_id=?");
preparedStatement.setInt(1,employeeIdNumericPart);
resultSet=preparedStatement.executeQuery();
String vName=null;
int vDesignationCode=0;
java.util.Date vDateOfBirth=null;
BigDecimal vBasicSalary=null;
boolean vIsIndian=false;
String vGender=null;
String vPanNumber=null;
String vAadharCardNumber=null;
if(resultSet.next())
{
vName=resultSet.getString("name");
vDesignationCode=resultSet.getInt("designation_code");
vDateOfBirth=resultSet.getDate("date_of_birth");
vBasicSalary=resultSet.getBigDecimal("basic_salary"); 
vIsIndian=resultSet.getBoolean("is_indian");
vGender=resultSet.getString("gender");
vPanNumber=resultSet.getString("pan_number");
vAadharCardNumber=resultSet.getString("aadhar_card_number");
}
employeeDTO=new EmployeeDTO();
employeeDTO.setName(vName);
employeeDTO.setDesignationCode(vDesignationCode);
employeeDTO.setDateOfBirth(vDateOfBirth);
employeeDTO.setBasicSalary(vBasicSalary);
employeeDTO.isIndian(vIsIndian);
if(vGender.equals("Male"))
employeeDTO.setGender(EmployeeDTOInterface.MALE);
else
employeeDTO.setGender(EmployeeDTOInterface.FEMALE);
employeeDTO.setPANNumber(vPanNumber);
employeeDTO.setAadharCardNumber(vAadharCardNumber);
resultSet.close();
preparedStatement.close();
connection.close();
return employeeDTO;
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
}
public EmployeeDTOInterface getByPANNumber(String panNumber) throws DAOException
{
try
{
EmployeeDTOInterface employeeDTO;
employeeDTO=new EmployeeDTO();
Connection connection=DAOConnection.getConnection();
PreparedStatement preparedStatement;
preparedStatement=connection.prepareStatement("select * from employee where pan_number=?");
preparedStatement.setString(1,panNumber);
ResultSet resultSet;
resultSet=preparedStatement.executeQuery();
if(resultSet.next()==false)
{
resultSet.close();
preparedStatement.close();
connection.close();
throw new DAOException("Invalid PAN Number : "+panNumber);
}
resultSet.close();
preparedStatement.close();
preparedStatement=connection.prepareStatement("select * from employee where pan_number=?");
preparedStatement.setString(1,panNumber);
resultSet=preparedStatement.executeQuery();
String vEmployeeId=null;
String vName=null;
int vDesignationCode=0;
java.util.Date vDateOfBirth=null;
BigDecimal vBasicSalary=null;
boolean vIsIndian=false;
String vGender=null;
String vAadharCardNumber=null;
if(resultSet.next())
{
vEmployeeId=resultSet.getString("employee_id");
vName=resultSet.getString("name");
vDesignationCode=resultSet.getInt("designation_code");
vDateOfBirth=resultSet.getDate("date_of_birth");
vBasicSalary=resultSet.getBigDecimal("basic_salary"); 
vIsIndian=resultSet.getBoolean("is_indian");
vGender=resultSet.getString("gender");
vAadharCardNumber=resultSet.getString("aadhar_card_number");
}
employeeDTO=new EmployeeDTO();
String newEmployeeId="EMP"+String.valueOf(100000+resultSet.getInt(1));
employeeDTO.setEmployeeId(newEmployeeId);
employeeDTO.setName(vName);
employeeDTO.setDesignationCode(vDesignationCode);
employeeDTO.setDateOfBirth(vDateOfBirth);
employeeDTO.setBasicSalary(vBasicSalary);
employeeDTO.isIndian(vIsIndian);
if(vGender.equals("Male"))
employeeDTO.setGender(EmployeeDTOInterface.MALE);
else
employeeDTO.setGender(EmployeeDTOInterface.FEMALE);
employeeDTO.setAadharCardNumber(vAadharCardNumber);
resultSet.close();
preparedStatement.close();
connection.close();
return employeeDTO;
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
}
public EmployeeDTOInterface getByAadharCardNumber(String aadharCardNumber) throws DAOException
{
try
{
EmployeeDTOInterface employeeDTO;
employeeDTO=new EmployeeDTO();
Connection connection=DAOConnection.getConnection();
PreparedStatement preparedStatement;
preparedStatement=connection.prepareStatement("select * from employee where aadhar_card_number=?");
preparedStatement.setString(1,aadharCardNumber);
ResultSet resultSet;
resultSet=preparedStatement.executeQuery();
if(resultSet.next()==false)
{
resultSet.close();
preparedStatement.close();
connection.close();
throw new DAOException("Invalid Aadhar Card Number : "+aadharCardNumber);
}
resultSet.close();
preparedStatement.close();
preparedStatement=connection.prepareStatement("select * from employee where aadhar_card_number=?");
preparedStatement.setString(1,aadharCardNumber);
resultSet=preparedStatement.executeQuery();
String vEmployeeId=null;
String vName=null;
int vDesignationCode=0;
java.util.Date vDateOfBirth=null;
BigDecimal vBasicSalary=null;
boolean vIsIndian=false;
String vGender=null;
String vPanNumber=null;
if(resultSet.next())
{
vEmployeeId=resultSet.getString("employee_id");
vName=resultSet.getString("name");
vDesignationCode=resultSet.getInt("designation_code");
vDateOfBirth=resultSet.getDate("date_of_birth");
vBasicSalary=resultSet.getBigDecimal("basic_salary"); 
vIsIndian=resultSet.getBoolean("is_indian");
vGender=resultSet.getString("gender");
vPanNumber=resultSet.getString("pan_number");
}
employeeDTO=new EmployeeDTO();
String newEmployeeId="EMP"+String.valueOf(100000+resultSet.getInt(1));
employeeDTO.setEmployeeId(newEmployeeId);
employeeDTO.setName(vName);
employeeDTO.setDesignationCode(vDesignationCode);
employeeDTO.setDateOfBirth(vDateOfBirth);
employeeDTO.setBasicSalary(vBasicSalary);
employeeDTO.isIndian(vIsIndian);
if(vGender.equals("Male"))
employeeDTO.setGender(EmployeeDTOInterface.MALE);
else
employeeDTO.setGender(EmployeeDTOInterface.FEMALE);
employeeDTO.setPANNumber(vPanNumber);
resultSet.close();
preparedStatement.close();
connection.close();
return employeeDTO;
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
}
public boolean EmployeeIdExists(String employeeId) throws DAOException
{
try
{
String vEmployeeId=employeeId;
if(vEmployeeId.length()<=3) return false

;int employeeIdNumericPart=Integer.parseInt(vEmployeeId.substring(3));

if(employeeIdNumericPart<=100000) return false;
employeeIdNumericPart=employeeIdNumericPart-100000;
Connection connection=DAOConnection.getConnection();
PreparedStatement preparedStatement;
preparedStatement=connection.prepareStatement("select * from employee where employee_Id=?");
preparedStatement.setInt(1,employeeIdNumericPart);
ResultSet resultSet;
resultSet=preparedStatement.executeQuery();
if(resultSet.next()==false)
{
resultSet.close();
preparedStatement.close();
connection.close();
return false;
}
resultSet.close();
preparedStatement.close();
connection.close();
return true;
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
}
public boolean panNumberExists(String panNumber) throws DAOException
{
try
{
EmployeeDTOInterface employeeDTO;
employeeDTO=new EmployeeDTO();
Connection connection=DAOConnection.getConnection();
PreparedStatement preparedStatement;
preparedStatement=connection.prepareStatement("select * from employee where pan_number=?");
preparedStatement.setString(1,panNumber);
ResultSet resultSet;
resultSet=preparedStatement.executeQuery();
if(resultSet.next()==false)
{
resultSet.close();
preparedStatement.close();
connection.close();
return false;
}
resultSet.close();
preparedStatement.close();
connection.close();
return true;
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
}
public boolean designationCodeExists(int designationCode) throws DAOException
{
try
{
EmployeeDTOInterface employeeDTO;
employeeDTO=new EmployeeDTO();
Connection connection=DAOConnection.getConnection();
PreparedStatement preparedStatement;
preparedStatement=connection.prepareStatement("select * from employee where designation_code=?");
preparedStatement.setInt(1,designationCode);
ResultSet resultSet;
resultSet=preparedStatement.executeQuery();
if(resultSet.next()==false)
{
resultSet.close();
preparedStatement.close();
connection.close();
return false;
}
resultSet.close();
preparedStatement.close();
connection.close();
return true;
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
}
public boolean aadharCardNumberExists(String aadharCardNumber) throws DAOException
{
try
{
EmployeeDTOInterface employeeDTO;
employeeDTO=new EmployeeDTO();
Connection connection=DAOConnection.getConnection();
PreparedStatement preparedStatement;
preparedStatement=connection.prepareStatement("select * from employee where aadhar_card_number=?");
preparedStatement.setString(1,aadharCardNumber);
ResultSet resultSet;
resultSet=preparedStatement.executeQuery();
if(resultSet.next()==false)
{
resultSet.close();
preparedStatement.close();
connection.close();
return false;
}
resultSet.close();
preparedStatement.close();
connection.close();
return true;
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
}
}