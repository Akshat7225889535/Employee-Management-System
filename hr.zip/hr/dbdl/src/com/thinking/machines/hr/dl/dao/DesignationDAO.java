


package com.thinking.machines.hr.dl.dao;
import java.util.*;
import java.io.*;
import java.sql.*;
import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.hr.dl.exceptions.*;
public class DesignationDAO implements DesignationDAOInterface
{
public void add(DesignationDTOInterface designationDTO) throws DAOException
{
try
{
Connection connection=DAOConnection.getConnection();
String vTitle=designationDTO.getTitle();
PreparedStatement preparedStatement;
preparedStatement=connection.prepareStatement("select *from designation where title=?");
preparedStatement.setString(1,vTitle);
ResultSet resultSet;
resultSet=preparedStatement.executeQuery();
if(resultSet.next()==true)
{
resultSet.close();
preparedStatement.close();
connection.close();
throw new DAOException(vTitle+ " already Exists");
}
resultSet.close();
preparedStatement.close();
preparedStatement=connection.prepareStatement("insert into designation (title) values (?)",Statement.RETURN_GENERATED_KEYS);
preparedStatement.setString(1,vTitle);
preparedStatement.executeUpdate();
resultSet=preparedStatement.getGeneratedKeys();
resultSet.next();
int code=resultSet.getInt(1);
designationDTO.setCode(code);
resultSet.close();
preparedStatement.close();
connection.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
}
public void update(DesignationDTOInterface designationDTO) throws DAOException
{
try
{
Connection connection=DAOConnection.getConnection();
String vTitle=designationDTO.getTitle();
int vCode=designationDTO.getCode();
PreparedStatement preparedStatement;
preparedStatement=connection.prepareStatement("select *from designation where code=?");
preparedStatement.setInt(1,vCode);
ResultSet resultSet;
resultSet=preparedStatement.executeQuery();
if(resultSet.next()==false)
{
resultSet.close();
preparedStatement.close();
connection.close();
throw new DAOException("Invalid Code : "+vCode);
}
resultSet.close();
preparedStatement.close();
preparedStatement=connection.prepareStatement("select * from designation where title=? and code!=?");
preparedStatement.setString(1,vTitle);
preparedStatement.setInt(2,vCode);
resultSet=preparedStatement.executeQuery();
if(resultSet.next()==true)
{
resultSet.close();
preparedStatement.close();
connection.close();
throw new DAOException(vTitle+ " already Exists");
}
resultSet.close();
preparedStatement.close();
preparedStatement=connection.prepareStatement("update designation set title=? where code =?");
preparedStatement.setString(1,vTitle);
preparedStatement.setInt(2,vCode);
preparedStatement.executeUpdate();
preparedStatement.close();
connection.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
}
public void delete(int code) throws DAOException
{
try
{
Connection connection=DAOConnection.getConnection();
PreparedStatement preparedStatement;
preparedStatement=connection.prepareStatement("select *from designation where code=?");
preparedStatement.setInt(1,code);
ResultSet resultSet;
resultSet=preparedStatement.executeQuery();
if(resultSet.next()==false)
{
resultSet.close();
preparedStatement.close();
connection.close();
throw new DAOException("Invalid Code : "+code);
}
resultSet.close();
preparedStatement.close();
preparedStatement=connection.prepareStatement("delete from designation where code=?");
preparedStatement.setInt(1,code);
preparedStatement.executeUpdate();
preparedStatement.close();
connection.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
}
public int getCount() throws DAOException
{
int count=0;
try
{
Connection connection=DAOConnection.getConnection();
Statement statement=connection.createStatement();
ResultSet resultSet;
resultSet=statement.executeQuery("Select * from designation");
while(resultSet.next())
{
count++;
}
resultSet.close();
statement.close();
connection.close();
}catch(Exception e)
{
System.out.println(e);
}
return count;
}
public List<DesignationDTOInterface> getAll() throws DAOException
{
List<DesignationDTOInterface> list;
DesignationDTOInterface designationDTO;
try
{
list=new LinkedList<>();
Connection connection=DAOConnection.getConnection();
Statement statement=connection.createStatement();
ResultSet resultSet;
int code;
String title;
resultSet=statement.executeQuery("select * from designation");
while(resultSet.next())
{
code=resultSet.getInt("code");
title=resultSet.getString("title").trim();
designationDTO=new DesignationDTO();
designationDTO.setCode(code);
designationDTO.setTitle(title);
list.add(designationDTO);
}
resultSet.close();
statement.close();
connection.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
return list;
}
public DesignationDTOInterface getByCode(int code) throws DAOException
{
DesignationDTOInterface designationDTO;
designationDTO=new DesignationDTO();
try
{
Connection connection=DAOConnection.getConnection();
int dCode=code;
PreparedStatement preparedStatement;
preparedStatement=connection.prepareStatement("select * from designation where code=?");
preparedStatement.setInt(1,dCode);
ResultSet resultSet;
resultSet=preparedStatement.executeQuery();
if(resultSet.next()==false)
{
resultSet.close();
preparedStatement.close();
connection.close();
throw new DAOException("Invalid Code : "+dCode);
}
resultSet.close();
preparedStatement.close();
preparedStatement=connection.prepareStatement("select * from designation where code=?");
preparedStatement.setInt(1,dCode);
resultSet=preparedStatement.executeQuery();
String title="";
if(resultSet.next())
{
title=resultSet.getString("title").trim();
}
resultSet.close();
preparedStatement.close();
connection.close();
designationDTO.setCode(dCode);
designationDTO.setTitle(title);
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
return designationDTO;
}
public DesignationDTOInterface getByTitle(String title) throws DAOException
{
DesignationDTOInterface designationDTO;
designationDTO=new DesignationDTO();
try
{
Connection connection=DAOConnection.getConnection();
PreparedStatement preparedStatement;
preparedStatement=connection.prepareStatement("select * from designation where title=?");
preparedStatement.setString(1,title);
ResultSet resultSet;
resultSet=preparedStatement.executeQuery();
if(resultSet.next()==false)
{
resultSet.close();
preparedStatement.close();
connection.close();
throw new DAOException("Invalid Designation");
}
resultSet.close();
preparedStatement.close();
preparedStatement=connection.prepareStatement("select * from designation where title=?");
preparedStatement.setString(1,title);
resultSet=preparedStatement.executeQuery();
int code=0;
if(resultSet.next())
{
code=resultSet.getInt("code");
}
resultSet.close();
preparedStatement.close();
connection.close();
designationDTO.setCode(code);
designationDTO.setTitle(title);
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
return designationDTO;
}
public boolean codeExists(int code) throws DAOException
{
try
{
Connection connection=DAOConnection.getConnection();
PreparedStatement preparedStatement;
preparedStatement=connection.prepareStatement("select * from designation where code=?");
preparedStatement.setInt(1,code);
ResultSet resultSet;
resultSet=preparedStatement.executeQuery();
if(resultSet.next()==false)
{
resultSet.close();
preparedStatement.close();
connection.close();
return false;
}
resultSet.close();
preparedStatement.close();
connection.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
return true;
}
public boolean titleExists(String title) throws DAOException
{
try
{
Connection connection=DAOConnection.getConnection();
PreparedStatement preparedStatement;
preparedStatement=connection.prepareStatement("select * from designation where title=?");
preparedStatement.setString(1,title);
ResultSet resultSet;
resultSet=preparedStatement.executeQuery();
if(resultSet.next()==false)
{
resultSet.close();
preparedStatement.close();
connection.close();
return false;
}
resultSet.close();
preparedStatement.close();
connection.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
return true;
}
}