package com.thinking.machines.hr.dl.interfaces;
public interface DesignationDTOInterface extends java.io.Serializable,Comparable<DesignationDTOInterface>
{
public void setCode(int code);
public int getCode();
public void setTitle(String title);
public String getTitle();
}